function [Vec_W_A]=JS_IndicatorFuseRW_Deepnet(A,netA,inputSizeA,layerA)

addpath(genpath('NSST_PAPCNN_Fusion'));

[R_LA,~]=size(A);
if R_LA==1
    A=A';
elseif R_LA~=1
    A=A;
end

R_A=cerecurr_y(A);

W_A=JS_WLToImage(A);
[RN,CN]=size(R_A);
W_A2=imresize(W_A,[RN,CN]);
imgf1=fuse_NSST_PAPCNN((abs(R_A)/max(max(R_A))),(abs(W_A2)/max(max(W_A2))) ); 

YWA = gray2rgb( imgf1 );

YWFA=im2uint8(YWA);

AauWFA=augmentedImageDatastore(inputSizeA(1:2),YWFA);

Vec_W_A(1,:)=activations(netA,AauWFA,layerA,'OutputAs','rows');


