clear,clc,close all,warning off

load('E:\Program\Orignal_Data.mat')

A=AA;
[N,~]=size(A);

netR=resnet18;
inputSizeR=netR.Layers(1).InputSize;
layerR='fc1000';

for i=1:30
    Train_A=A{i,1};
    Test_A=A{i,2};
    [Tes_N,~]=size(Test_A);
    [Tra_N,~]=size(Train_A);
    eps_SF=zeros(Tes_N,1);
    
    Index_SF=0;
    
    for j=1:Tes_N
        Test_AJ=Test_A(j,2:end);
        D_SF=zeros(Tra_N,1);

        [TR_RW]=JS_IndicatorFuseRW_Deepnet( Test_AJ,netR,inputSizeR,layerR);
       
        for k=1:Tra_N
            Tra_AJ=Train_A(k,2:end);

              [TE_RW]=JS_IndicatorFuseRW_Deepnet(Tra_AJ,netR,inputSizeR,layerR);            

            %% Calculate the distance of the characteristic
            [D_SF(k,1)]=JS_DisSimEu_Matrix(TR_RW,TE_RW);


            
        end
        %% Calculate 1nn classification accuracy
        Index_SF=find(D_SF==min(D_SF));
        
         N_SF=length(Index_SF);
        if N_SF==1
            if Test_A(j,1)==Train_A(Index_SF,1)
                eps_SF(j,1)=1;
            else
                eps_SF(j,1)=0;
            end
        else
            for i1=1:N_SF
                if Test_A(j,1)==Train_A(Index_SF(i1,1),1)
                    eps_SF(j,1)=1;
                end
            end
        end
              
        js2=[i,j]
    end
    Acc_SF(i,1)=length(find(eps_SF==1))/Tes_N;
    
    
    js1=i
end
