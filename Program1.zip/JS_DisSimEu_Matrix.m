function [D_SF]=JS_DisSimEu_Matrix(AVec_M_A,BVec_M_A)

D_SF=pdist2(AVec_M_A(1,:),BVec_M_A(1,:),'euclidean');

