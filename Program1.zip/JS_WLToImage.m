function IWL=JS_WLToImage(X)

wavename='cmor1-7';
totalscal=1000;
Fc=centfrq(wavename); 
c=2*Fc*totalscal;
scals=c./(1:totalscal);

coefs=cwt(X,scals,wavename); 

IWL=abs(coefs);


