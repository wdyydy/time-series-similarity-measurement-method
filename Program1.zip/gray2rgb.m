function y = gray2rgb( x )

d = size(x);

temp = zeros(d(1),d(2),3);

temp(:, :,1 ) = x;
temp(:, :,2 ) = x;
temp(:, :,3 ) = x;

y = temp;