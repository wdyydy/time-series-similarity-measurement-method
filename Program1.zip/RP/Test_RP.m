clear,clc,close all


ecg = load('Ecgn.dat');

y = phasespace(ecg,3,8);

figure(1)
cerecurr_y(y);
figure(2)
cerecurr_y(ecg);
recurdata = cerecurr_y(y);
recurdata2 = cerecurr_y(ecg);

figure(4)
imshow(recurdata)
figure(5)
imshow(recurdata2)